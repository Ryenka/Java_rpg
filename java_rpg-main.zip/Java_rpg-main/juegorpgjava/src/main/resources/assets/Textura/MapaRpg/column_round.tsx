<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="column_round" tilewidth="32" tileheight="32" tilecount="2" columns="1">
 <image source="../tiles/tilesets/column_round.png" width="32" height="64"/>
</tileset>
