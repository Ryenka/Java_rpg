package Interfaz;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public interface Dibujo {
    void draw(SpriteBatch batch);
}
