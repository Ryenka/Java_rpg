package Interfaz;

public interface Actualizacion {
    void update(float delta);
}
