package Principal;

import juegoRpg.JavaFxPant;

public class Principal {
    public static void main(String[] args) {
        JavaFxPant.launchApp(args);
    }
}
