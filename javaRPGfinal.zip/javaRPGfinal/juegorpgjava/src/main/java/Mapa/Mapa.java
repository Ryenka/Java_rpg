package Mapa;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class Mapa {
    private TiledMap tiledMap;
    private OrthogonalTiledMapRenderer renderer;
    private OrthographicCamera camera;
    private static final int TILE_SIZE = 31; // Size of the map tiles in pixels

    public Mapa(String mapaPath, OrthographicCamera camera) {
        try {
            // Load the tiled map
            this.tiledMap = new TmxMapLoader().load(mapaPath);
            this.renderer = new OrthogonalTiledMapRenderer(tiledMap);
            this.camera = camera;
        } catch (com.badlogic.gdx.utils.GdxRuntimeException e) {
            System.err.println("Error cargando mapa: " + mapaPath);
            e.printStackTrace();
            throw e; // Consider handling the exception in a more user-friendly way
        }
    }

    public void render(SpriteBatch batch) {
        camera.update(); // Update the camera
        renderer.setView(camera); // Set the view for the renderer
        renderer.render(); // Render the map
    }

    public void dispose() {
        if (tiledMap != null) {
            tiledMap.dispose();
        }
        if (renderer != null) {
            renderer.dispose();
        }
    }

    public OrthographicCamera getCamera() {
        return camera;
    }

    public TiledMap getTiledMap() {
        return tiledMap;
    }

    public int toWorldCoordinate(int gridCoordinate) {
        return gridCoordinate * TILE_SIZE;
    }

    public int toGridCoordinate(float worldCoordinate) {
        return (int) (worldCoordinate / TILE_SIZE);
    }
}


