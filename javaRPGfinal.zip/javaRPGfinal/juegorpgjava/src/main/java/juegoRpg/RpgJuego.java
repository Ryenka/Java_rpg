package juegoRpg;

import Mapa.Mapa;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class RpgJuego extends Game {
    public SpriteBatch batch;
    public OrthographicCamera camera;
    public Mapa mapa;


    @Override
    public void create() {
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 600); // Configure the camera
        mapa = new Mapa("assets/Textura/MapaRpg/rpgMapa.tmx", camera);

        // Set the screen after initializing camera and map
        this.setScreen(new MenuPantalla(this));
    }

    @Override
    public void render() {
        super.render(); // This will call render() method of the active screen
    }

    @Override
    public void dispose() {
        batch.dispose();
        mapa.dispose();
    }
}

