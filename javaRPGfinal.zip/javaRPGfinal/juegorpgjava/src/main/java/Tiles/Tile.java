package Tiles;

public class Tile {
}
