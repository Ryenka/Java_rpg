<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="column_square_wall" tilewidth="32" tileheight="32" tilecount="3" columns="1">
 <image source="../tiles/tilesets/column_square_wall.png" width="32" height="96"/>
</tileset>
